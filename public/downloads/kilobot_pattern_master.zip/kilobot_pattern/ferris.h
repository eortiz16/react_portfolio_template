

#define MAX_NUM_NEIGHBORS 15
#define SHARING_TIME 10
#define TOKEN_TIME 103

#define FALSE 0
#define TRUE 255


//PAYLOAD

//universal slots
#define MSG 0
#define ID 1
#define GRAD 2

//seed determination slots
#define RULER 3
#define WAR 4
#define ENTITY 5
#define SEEDED 6
#define SEEDA_ID 7
#define SEEDB_ID 8

//node placement slots
#define TYPE 3
#define TARGET_ID 4
#define RESPONSE_ID 5
#define RESPONSE_VAL 6
#define COORDINATES 7
#define SAFE 8

#define ACTIVE 0


#define QUEUE 2

//COORDINATE ENUMERATION
//assumes OVERLORD sits north of the two
//other seed bots
#define ORIGIN 0 //OVERLORD
#define SEEDA  1 //SEED A
#define SEEDB  2 //SEED B

#define   N  3 //NORTH
#define  NE  4 //NORTHEAST
#define SSE  5 //SOUTHEAST
#define   S  6 //SOUTH
#define  SW  7 //SOUTHWEST
#define  NW  8 //NORTHWEST
#define FNE  9 //FAR NORTHEAST
#define  FE 10 //FAR EAST
#define FSE 11 //FAR SOUTHEAST
#define FSW 12 //FAR SOUTHWEST
#define  FW 13 //FAR WEST
#define FNW 14 //FAR NORTHWEST

typedef struct {
    uint8_t d_origin;
    uint8_t d_seeda;
    uint8_t d_seedb;
    uint8_t d_N;
    uint8_t d_NE;
    uint8_t d_SE;
    uint8_t d_S;
    uint8_t d_SW;
    uint8_t d_NW;
    uint8_t d_FNE;
    uint8_t d_FE;
    uint8_t d_FSE;
    uint8_t d_FSW;
    uint8_t d_FW;
    uint8_t d_FNW;
    uint8_t desig_id;
    uint8_t placed;
} gps_t;

#ifndef M_PI
#define M_PI 3.141592653589793238462643383279502884197169399375105820974944
#endif

typedef enum {
    NULL_MSG,   //0
    SHARE,      //1
    JOIN,       //2
    LEAVE,      //3
    MOVE,       //4
    SEARCH,     //5
    UPDATE,     //6
    PLACED,     //7
    RESPONSE    //8
} message_type;  // MESSAGES


// declare motion variable type
typedef enum {
    STOP,
    FORWARD,
    LEFT,
    RIGHT,
    FAST_FORWARD
} motion_t;

typedef struct{
    uint8_t id;
    uint8_t distance;
    uint8_t grad;
    uint8_t type;
    uint8_t ruler;
    uint8_t resp_val;
    uint8_t safe;
    uint8_t resp_id;

    uint8_t message_recv_delay;

} nearest_neighbor_t;

typedef struct  {
    uint8_t motion;
    uint8_t time;
} motion_time_t;

//Status of states 
typedef enum {

    SOVEREIGN, 
    WARLORD,
    VASSAL,
    TRIBUTE,
    OVERLORD,
    SEED
} sovereignty_t;

typedef struct
{
    uint8_t my_id;
    message_t message[QUEUE];
    message_t nullmessage;
    
    uint8_t num_neighbors;
    uint8_t message_sent;
    uint32_t now;
    uint32_t nextShareSending;
    uint8_t cur_motion;
    uint8_t motion_state;
    uint8_t time_active;
    uint8_t move_state;
    nearest_neighbor_t nearest_neighbors[MAX_NUM_NEIGHBORS];
    motion_time_t move_motion[3];
    char send_token;
    uint8_t green;
    uint8_t red;
    uint8_t blue;
    int8_t token;
    int8_t head, tail;
    int8_t copies;
    uint8_t loneliness;
    uint8_t ruler_id;
    sovereignty_t entity;
    uint8_t gradient;
    gps_t gps[MAX_NUM_NEIGHBORS];
    uint8_t my_coord;
    uint8_t msg_log[2];
    uint32_t seed_time;
    uint32_t last_placed_time;
    uint32_t last_update_time;
    uint8_t resp_val;
    uint8_t resp_id;
    uint8_t progress;
    
    uint8_t Vmin;
    motion_t state;
    uint8_t changeTicks;
    uint8_t badsteps;
    uint8_t orbit_target;
    uint8_t climb_dist;
    uint8_t climb_target;
    uint8_t prev_climb;
    
    uint8_t cleaning;
    uint32_t clean_time;
    
    //seed determination flags
    uint8_t war;
    uint8_t seeded;
    
    //node placement flags
    uint8_t safe;
    uint8_t forming;
    uint8_t placed;
    uint8_t searching;
    uint8_t moving;
    uint8_t responding;
    uint8_t updating;

} USERDATA;
