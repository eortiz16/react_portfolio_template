#define SIMULATOR


#ifndef SIMULATOR
   #include <kilolib.h>
    #include <avr/io.h>  // for microcontroller register defs
    #include "ferris.h"
    USERDATA myData;
    USERDATA *mydata = &myData;
#else
    #include <kilombo.h> 
    #include "ferris.h"
    #include <math.h>
    #include <stdio.h> // for printf
    
    REGISTER_USERDATA(USERDATA)
#endif

//PROTOTYPES
void seed_start();
void forward(uint8_t*);


char isQueueFull()
{
    return (mydata->tail +1) % QUEUE == mydata->head;
}

void clean() {
    mydata->cleaning = TRUE;
    mydata->clean_time = mydata->now;
}


/* Helper function for setting motor speed smoothly
 */
void smooth_set_motors(uint8_t ccw, uint8_t cw)
{
    // OCR2A = ccw;  OCR2B = cw;
#ifdef KILOBOT
    uint8_t l = 0, r = 0;
    if (ccw && !OCR2A) // we want left motor on, and it's off
        l = 0xff;
    if (cw && !OCR2B)  // we want right motor on, and it's off
        r = 0xff;
    if (l || r)        // at least one motor needs spin-up
    {
        set_motors(l, r);
        delay(15);
    }
#endif
    // spin-up is done, now we set the real value
    set_motors(ccw, cw);
}


void set_motion(motion_t new_motion)
{
    switch(new_motion) {
        case STOP:
            smooth_set_motors(0,0);
            break;
        case FORWARD:
            smooth_set_motors(kilo_straight_left, kilo_straight_right);
            break;
        case LEFT:
            smooth_set_motors(kilo_turn_left, 0);
            break;
        case RIGHT:
            smooth_set_motors(0, kilo_turn_right); 
            break;
        case FAST_FORWARD:
            smooth_set_motors(70,70);
            break;
    }
}


char in_interval(uint8_t distance)
{
    //if (distance >= 40 && distance <= 60)
    if (distance <= 90)
        return 1;
    return 0;
}

// Search for id in the neighboring nodes
uint8_t exists_nearest_neighbor(uint8_t id)
{
    uint8_t i;
    for (i=0; i<mydata->num_neighbors; i++)
    {
        if (mydata->nearest_neighbors[i].id == id)
            return i;
    }
    return i;
}

void update_color()
{
//#define RULER_CHECK
#define STATE_CHECK
//#define SEED_CHECK
//#define SEEDA_CHECK
//#define SEEDB_CHECK
//#define GRAD_CHECK
//#define SAFE_CHECK
#define SEARCH_CHECK
//#define COLOR_CHECK
//#define GPS_CHECK
//#define RESP_CHECK
//#define CLEAN_CHECK

#ifdef CLEAN_CHECK
    if(mydata->cleaning == TRUE) set_color(RGB(3,0,0));
    else set_color(0);
#endif

    //state check
#ifdef STATE_CHECK
    if(mydata->entity == SOVEREIGN) {
        set_color(RGB(0,0,3));
    }
    else if(mydata->entity == WARLORD) {
        set_color(RGB(3,0,0));
    }
    else if(mydata->entity == VASSAL) {
        set_color(RGB(3,3,0));
    }
    else if(mydata->entity == TRIBUTE) {
        set_color(RGB(3,0,3));
    }
    else if(mydata->entity == OVERLORD) {
        set_color(0);
    }
#endif

    //misc color checking
#ifdef COLOR_CHECK
    set_color(RGB(mydata->red,mydata->green,mydata->blue));
#endif

#ifdef SAFE_CHECK
    if(mydata->safe == TRUE) set_color(RGB(0,3,0));
    else set_color(0);
#endif

    //search check
#ifdef SEARCH_CHECK
    if(mydata->placed == TRUE) set_color(RGB(3,3,3));
    else if(mydata->moving == TRUE) set_color(RGB(3,0,0));
    else if(mydata->responding == TRUE) set_color(RGB(0,0,3));
    else if(mydata->searching == TRUE) set_color(RGB(0,3,0));
    else if(mydata->forming == TRUE) set_color(RGB(1,1,0));
#endif

#ifdef RESP_CHECK
    set_color(mydata->resp_id);
#endif

#ifdef GRAD_CHECK
    uint8_t colors[] = {
        RGB(0,0,0),  //0 - off
        RGB(2,0,0),  //1 - red
        RGB(2,1,0),  //2 - orange
        RGB(2,2,0),  //3 - yellow
        RGB(1,2,0),  //4 - yellowish green
        RGB(0,2,0),  //5 - green
        RGB(0,1,1),  //6 - cyan
        RGB(0,0,1),  //7 - blue
        RGB(1,0,1),  //8 - purple
        RGB(3,3,3)   //9  - bright white
    };
    set_color(colors[mydata->gradient]);
#endif

    //seed check
#ifdef SEED_CHECK
    if(mydata->seeded == TRUE) {
        set_color(RGB(0,3,0));
    }
#endif
    
    //ruler check
#ifdef RULER_CHECK
    set_color(mydata->ruler_id);
#endif
    
    //SEED A check
#ifdef SEEDA_CHECK
    set_color(mydata->gps[SEEDA].desig_id);
#endif

    //SEED B check
#ifdef SEEDB_CHECK
    set_color(mydata->gps[SEEDB].desig_id);
#endif

    //GPS CHECK
#ifdef GPS_CHECK
    set_color(mydata->gps[N].desig_id);
#endif
}
// dynamically updatyes your graduate based on nenighbors 
//This is a constanmt bellmanford 
void update_gradient() {
    if(mydata->entity == OVERLORD || mydata->entity == SEED) {
        mydata->gradient = 0;
    }
    else {
        uint8_t i;
        mydata->gradient = 255;
        for(i = 0; i < mydata->num_neighbors; i++) {
            if(mydata->gradient > mydata->nearest_neighbors[i].grad) {
                mydata->gradient = mydata->nearest_neighbors[i].grad + 1;
            }
        }
    }
}
//Used in seed determination when overloard is determed he sets seeda and seedb so they 
//can be uniquly identified 
void twin_seed(){
    uint8_t i; 
    uint8_t j = 1;
    for(i = 0; i < mydata->num_neighbors; i++) {
        if(mydata->nearest_neighbors[i].distance < 40) {
            mydata->gps[j].desig_id = mydata->nearest_neighbors[i].id;
            j++; 
        }
    }
}
//This is basically the pseduocode1 
//Read the documentation please 
void seed_determination(uint8_t *payload, uint8_t i){
    
    mydata->nearest_neighbors[i].type = payload[ENTITY];
    mydata->nearest_neighbors[i].ruler = payload[RULER];
    if(((mydata->entity != WARLORD && (mydata->ruler_id == mydata->my_id
            || payload[RULER] < mydata->ruler_id)))
            || payload[RULER] < mydata->ruler_id) {
        mydata->ruler_id = payload[RULER];
        mydata->gradient = payload[GRAD] + 1;
        mydata->entity = VASSAL;
        mydata->war = TRUE;
    }
    uint8_t j;
    uint8_t k = 0;
    for(j = 0; j < mydata->num_neighbors; j++) {
        if(mydata->nearest_neighbors[j].ruler == mydata->ruler_id
                && mydata->ruler_id != mydata->my_id) {
            if(mydata->nearest_neighbors[j].type != VASSAL
                    || (mydata->nearest_neighbors[j].type == VASSAL
                    && mydata->nearest_neighbors[j].grad <= mydata->gradient)) {
                k++;
            }
        }
    }
    if(k == mydata->num_neighbors) {
        mydata->entity = TRIBUTE;
    }
    k = 0;
    for(j = 0; j < mydata->num_neighbors; j++) {
        if(mydata->entity == WARLORD
                && mydata->nearest_neighbors[j].type == TRIBUTE) {
            k++;
        }
    }
    if(k == mydata->num_neighbors) {
        mydata->entity = OVERLORD;
        mydata->gps[ORIGIN].desig_id = mydata->my_id;
        twin_seed();
        mydata->seeded = TRUE;
        mydata->seed_time = mydata->now;
        mydata->last_placed_time = mydata->now + 50;
        mydata->message[mydata->tail].data[ENTITY] = mydata->entity;
        mydata->message[mydata->tail].data[SEEDED] = mydata->seeded;
        mydata->message[mydata->tail].data[SEEDA_ID] = mydata->gps[SEEDA].desig_id;
        mydata->message[mydata->tail].data[SEEDB_ID] = mydata->gps[SEEDB].desig_id;
        
    }
    if(payload[SEEDED] == TRUE) {
        mydata->gps[ORIGIN].desig_id = mydata->ruler_id;
        mydata->gps[SEEDA].desig_id = payload[SEEDA_ID];
        mydata->gps[SEEDB].desig_id = payload[SEEDB_ID];
        if(mydata->my_id == payload[SEEDA_ID] || mydata->my_id == payload[SEEDB_ID]) {
            mydata->entity = SEED;
        }
        mydata->seeded = TRUE;
        mydata->seed_time = mydata->now;
        mydata->message[mydata->tail].data[ENTITY] = mydata->entity;
        mydata->message[mydata->tail].data[SEEDED] = mydata->seeded;
        mydata->message[mydata->tail].data[SEEDA_ID] = mydata->gps[SEEDA].desig_id;
        mydata->message[mydata->tail].data[SEEDB_ID] = mydata->gps[SEEDB].desig_id;
    }
}
// If you are a leaf then you are automatically safe 
//This function just checks if you are a leafe
//This is were resp_val is first calculated and pass up 
void leaf_check(uint8_t *payload) {
    uint8_t j;
    for(j = 0; j < mydata->num_neighbors; j++) {
        if(mydata->nearest_neighbors[j].grad > mydata->gradient) {
            forward(payload);
            return;
        }
    }
    mydata->resp_val = mydata->gradient * 10;
    mydata->resp_id = mydata->my_id;
    mydata->safe = TRUE;
    //if(kilo_uid == 13) printf("leaf safe\n");
    mydata->responding = TRUE;
    mydata->searching = FALSE;
}

void recv_sharing(uint8_t *payload, uint8_t distance)
{
    if (payload[ID] == mydata->my_id  || payload[ID] == 0) return;
    
    mydata->loneliness = 0;

    uint8_t i = exists_nearest_neighbor(payload[ID]);
    if (i >= mydata->num_neighbors) // The id has never received
    {
        if (mydata->num_neighbors < MAX_NUM_NEIGHBORS)
        {
            i = mydata->num_neighbors;
            mydata->num_neighbors++;
        }
    }

    
    mydata->nearest_neighbors[i].id = payload[ID];
    mydata->nearest_neighbors[i].distance = distance;
    mydata->nearest_neighbors[i].grad = payload[GRAD];
    
    mydata->nearest_neighbors[i].message_recv_delay = 0;
    // Ifs below are based on your statues type and what to do with the data and type fo message 
    if(mydata->seeded == TRUE) {
        update_gradient();
        mydata->nearest_neighbors[i].safe = payload[SAFE];
    }
    
    if(mydata->seeded == FALSE && payload[WAR] != FALSE) {
        seed_determination(payload, i);
    }
    
    if(payload[TYPE] == SEARCH && mydata->safe == FALSE
            && mydata->entity != OVERLORD) {
        mydata->searching = TRUE;
        mydata->updating = FALSE;
        leaf_check(payload);
    }
    
    if(payload[TYPE] == RESPONSE && payload[SAFE] == TRUE && mydata->safe == FALSE) {
            
        mydata->nearest_neighbors[i].resp_val = payload[RESPONSE_VAL];
        mydata->nearest_neighbors[i].safe = payload[SAFE];
        mydata->nearest_neighbors[i].resp_id = payload[RESPONSE_ID];
    }
    
    if(payload[TYPE] == MOVE && mydata->entity != OVERLORD) {
        mydata->moving = TRUE;
        mydata->my_coord = payload[COORDINATES];
        mydata->gps[payload[COORDINATES]].desig_id = mydata->my_id;
    }
    
    if(payload[TYPE] == UPDATE && mydata->gps[payload[COORDINATES]].desig_id == 0) {
        mydata->last_update_time = mydata->now;
        mydata->gps[payload[COORDINATES]].desig_id = payload[RESPONSE_ID];
        
        if(mydata->entity == OVERLORD && mydata->moving == TRUE) {
            if(payload[RESPONSE_ID] == mydata->resp_id) {
                mydata->last_placed_time = mydata->now;
                mydata->moving = FALSE;
                mydata->progress++;
            }
        }
        mydata->resp_id = 0;
        mydata-> resp_val = 0;
        mydata->safe = FALSE;
        forward(payload);
        clean();
    }
    //This is updating color 
    update_color();

}

void recv_joining(uint8_t *payload)
{
    //"joining"
}

void recv_move(uint8_t *payload)
{
/*
    if (mydata->my_id == payload[RECEIVER])
    {
        mydata->token  = 1;
        mydata->blue  = 1;
        mydata->send_token = mydata->now + TOKEN_TIME * 4.0;

    }
    else if (my_id == payload[SENDER])
    {
        mydata->motion_state = STOP;
    }
    else
    {
        mydata->msg.data[MSG]      = payload[MSG];
        mydata->msg.data[ID]       = mydata->my_id;
        mydata->msg.data[RECEIVER] = payload[RECEIVER];
        mydata->msg.data[SENDER]   = payload[SENDER];
        mydata->msg.type           = NORMAL;
        mydata->msg.crc            = message_crc(&msg);
        mydata->message_sent       = 0;
    } */
}
//Just keep forwarding the message 
//This function is disabled by the cleaning flag 
void forward(uint8_t *payload) {
    uint8_t i;
    if(mydata->cleaning == FALSE) {
        for(i = 3; i < 9; i++) {
            mydata->message[mydata->tail].data[i] = payload[i];
        }
    }
}

void message_rx(message_t *m, distance_measurement_t *d)
{    
    uint8_t dist = estimate_distance(d);
    
    if(m->type == NORMAL && m->data[MSG] !=NULL_MSG)
    {
        // if a move messages has reached you stop responding 
        if(m->data[TYPE] == MOVE) {
            mydata->responding = FALSE;
        }
    
        /*if(kilo_uid == 10) {
            printf("\nnow: %d\n",mydata->now);
            uint8_t i;
            for(i = 1; i < 9; i++) {
                printf("%d\n",m->data[i]);
            }
        }*/
        // if broadcast id is 255 no matter what accept it 
        if(m->data[TARGET_ID] == 255) {
            recv_sharing(m->data, dist);
        }
        //if we finish seeding and the target id is not you forward the message 
        else if(mydata->forming == TRUE && m->data[TARGET_ID] != mydata->my_id
                && mydata->entity != OVERLORD) {
             //if the target id is the same as previous message then dont forward it    
            if(m->data[TARGET_ID] != mydata->msg_log[0]
                    && m->data[TARGET_ID] != mydata->msg_log[1]) {    
                forward(m->data);
                mydata->msg_log[1] = mydata->msg_log[0];
                mydata->msg_log[0] = m->data[TARGET_ID];
            }
        }
        //Mostly used for seed, however if nothing else applies the accept message 
        else {
            recv_sharing(m->data, dist);
        }
        /*switch (m->data[MSG])
        {
            case JOIN:
                recv_joining(m->data);
                break;
            case MOVE:
                recv_move(m->data);
                break;
        
        }*/
    }
}

//Most payload assignments are in functions below 
char enqueue_message(uint8_t m)
{
    if (!isQueueFull())
    {
        mydata->message[mydata->tail].data[MSG] = m;
        mydata->message[mydata->tail].data[ID] = mydata->my_id;
        mydata->message[mydata->tail].data[GRAD] = mydata->gradient;
        if(mydata->forming == TRUE) {
            mydata->message[mydata->tail].data[SAFE] = mydata->safe;
        }
        
        mydata->message[mydata->tail].type = NORMAL;
        mydata->message[mydata->tail].crc = message_crc(&mydata->message[mydata->tail]);
        mydata->tail++;
        mydata->tail = mydata->tail % QUEUE;
        /*if(kilo_uid == 13) {
            printf("\nnow: %d\n",mydata->now);
            uint8_t i;
            for(i = 1; i < 9; i++) {
                printf("%d\n",mydata->message[mydata->tail].data[i]);
            }
        }*/
        return 1;
    }
    return 0;
}

/**********************************/
/**********************************/
void send_joining()
{
    //send "joining"
}

void send_sharing()
{
    // Precondition
    if (mydata->now >= mydata->nextShareSending  && !isQueueFull())
    {
        // Sending
        enqueue_message(SHARE);
        // effect:
        mydata->nextShareSending = mydata->now + SHARING_TIME;
    }
}

void move(uint8_t tick)
{
    //move stuff
}

//This functions works to reset the bots when they 
// have broken the ring 
void reset_self()
{
    mydata->num_neighbors = 0;
}
//This function is called when message_recv_delay is > than X time
//Add extra funtionallty for cleaning neighbor data 
void remove_neighbor(nearest_neighbor_t lost)
{
    uint8_t lost_bot_index;
    lost_bot_index = exists_nearest_neighbor(lost.id);
    
    mydata->nearest_neighbors[lost_bot_index] =
            mydata->nearest_neighbors[mydata->num_neighbors-1];
    mydata->nearest_neighbors[mydata->num_neighbors-1].id = 0;
    mydata->nearest_neighbors[mydata->num_neighbors-1].distance = 255;
    mydata->nearest_neighbors[mydata->num_neighbors-1].grad = 255;
    mydata->nearest_neighbors[mydata->num_neighbors-1].type = 0;
    mydata->nearest_neighbors[mydata->num_neighbors-1].ruler = 0;
    mydata->nearest_neighbors[mydata->num_neighbors-1].resp_val = 0;
    mydata->nearest_neighbors[mydata->num_neighbors-1].safe = FALSE;
    mydata->nearest_neighbors[mydata->num_neighbors-1].resp_id = 0;

    mydata->nearest_neighbors[mydata->num_neighbors-1].message_recv_delay = 0;
    
    mydata->num_neighbors--;
}
//When you are in the seeding stage this is what you are 
//Assigning into the payload slots 
void seeding_update() {
    mydata->message[mydata->tail].data[RULER] = mydata->ruler_id;
    mydata->message[mydata->tail].data[WAR] = mydata->war;
    mydata->message[mydata->tail].data[ENTITY] = mydata->entity;
    mydata->message[mydata->tail].data[SEEDED] = mydata->seeded;
}
//Cuurently unused 
//DO NOT DELET 
void forming_update() {
    mydata->message[mydata->tail].data[TYPE] = 0;
    mydata->message[mydata->tail].data[TARGET_ID] = 255;
    mydata->message[mydata->tail].data[RESPONSE_ID] = 0;
    mydata->message[mydata->tail].data[RESPONSE_VAL] = 0;
    mydata->message[mydata->tail].data[COORDINATES] = 0;
}
//Comes from overlord and starts new search 
void search_brdcst() {
    mydata->searching = TRUE;
    mydata->message[mydata->tail].data[TYPE] = SEARCH;
    mydata->message[mydata->tail].data[TARGET_ID] = 255;
    mydata->message[mydata->tail].data[RESPONSE_ID] = 0;
    mydata->message[mydata->tail].data[RESPONSE_VAL] = 0;
    mydata->message[mydata->tail].data[COORDINATES] = 0;
}
//Response to a search broadcast 
void search_cnvgcst() {
    uint8_t j;
    uint8_t child_val = 0;
    for(j = 0; j < mydata->num_neighbors; j++) {
    //If true brak from convergcast becasue neighbors arnt ready 
    //And for overlord everyone needs to be safe first 
        if((mydata->nearest_neighbors[j].grad > mydata->gradient
                || mydata->entity == OVERLORD)
                && mydata->nearest_neighbors[j].safe == FALSE) {
            return;
        }
    }
    //This is where convergcast decision is made 
    //child_val is what is being passed up the tree 
    //resp_id is associate with the child value that we chose 
    for(j = 0; j < mydata->num_neighbors; j++) {
         child_val = mydata->nearest_neighbors[j].resp_val
                + (mydata->nearest_neighbors[j].distance / 10);
        if((mydata->nearest_neighbors[j].grad > mydata->gradient
                ||mydata->entity == OVERLORD)
                && child_val > mydata->resp_val) {
            mydata->resp_val = child_val;
            mydata->resp_id = mydata->nearest_neighbors[j].resp_id;
        }
    }
    //If you got threw the 1st for loop then you are safe 
    mydata->safe = TRUE;
    //if(kilo_uid == 13) printf("cnvg safe\n");
    
    //You hit the responding flag and the values are being 
    //assigned into your payload 
    if(mydata->entity != OVERLORD) {
        mydata->responding = TRUE;
    }
    //searching is set to false because you have finished with 
    //specific search 
    mydata->searching = FALSE;
}
//When convergcast says you are safe 
void search_response() {
    mydata->message[mydata->tail].data[TYPE] = RESPONSE;
    mydata->message[mydata->tail].data[TARGET_ID] = 255;
    mydata->message[mydata->tail].data[RESPONSE_ID] = mydata->resp_id;
    mydata->message[mydata->tail].data[RESPONSE_VAL] = mydata->resp_val;
    mydata->message[mydata->tail].data[COORDINATES] = 0;
}
//Sent from overlord 
void send_move(uint8_t coordinate) {
    mydata->moving = TRUE;
    mydata->safe = FALSE;
    mydata->message[mydata->tail].data[TYPE] = MOVE;
    mydata->message[mydata->tail].data[TARGET_ID] = mydata->resp_id;
    mydata->message[mydata->tail].data[RESPONSE_ID] = 0;
    mydata->message[mydata->tail].data[RESPONSE_VAL] = 0;
    mydata->message[mydata->tail].data[COORDINATES] = coordinate;
    //printf("move target: %d\n",mydata->resp_id);
}

// torn from follow.c example
void gradient_climb(uint8_t V) {
    
    uint8_t otherstate;
    otherstate = (mydata->state==LEFT)?RIGHT:LEFT;
    
    if(mydata->climb_target != mydata->prev_climb) mydata->Vmin = 255;
    
    if (V < mydata->Vmin) {     // potential decreased
        mydata->Vmin = V;       // store new minimum
        mydata->badsteps = 0;   // reset badsteps-counter
    }

    if (mydata->changeTicks > 0) {  // after changing direction, don't change back immediately
        mydata->changeTicks--;
        if (mydata->changeTicks == 0) {
            if (V >  mydata->Vmin) {    // this step was in a bad direction.
                                        // If this happens for two consecutive
                mydata->badsteps++;     // moves, we're heading the wrong way. keep turning
            }
        mydata->Vmin = V;        // dead-time ended. Store current distance as minimum.
        }
    }
    else if (V > mydata->Vmin && mydata->badsteps < 1) {    // passed minimum distance.
        mydata->state = otherstate;  // change direction
        mydata->Vmin = V;
        mydata->changeTicks = 35;    // length of dead time after direction change    
    }
    
    set_motion(mydata->state);
}

//If yout closer turn one direction if you ate farther the other direction 
void avoidance_orbit(uint8_t radius) {
    if(radius > 47) set_motion(RIGHT);
    else set_motion(LEFT);
}
//This function is decied by the orbit target in movement 
void seed_orbit(uint8_t target, uint8_t rad) {
    
    uint8_t i,j;
    uint8_t dist = 0;
    //Current didstance to your orbit target 
    dist = mydata->nearest_neighbors[exists_nearest_neighbor(target)].distance;

    //if(kilo_uid == 10) {printf("%d\n",target);}
    
    /*for(i = 3; i < mydata->my_coord; i++) {
        for(j = 0; i < mydata->num_neighbors; i++) {
            if(mydata->nearest_neighbors[j].id == mydata->gps[i].desig_id
                    && mydata->nearest_neighbors[j].distance < 55)
                avoidance_orbit(mydata->nearest_neighbors[j].distance);
                return;
        }
    }*/
    
    //This is the orbit function
    if(dist > rad)
        set_motion(RIGHT);
    else set_motion(LEFT);
}
//This function controls the movement of the bots
//DO NOT CHANGE FOR NOW PLEASE
void movement() {
    uint8_t i,j,k;
    j = 255;
    k = 0;
    uint8_t target; //Orbiting target NOT DESTINATION 
    uint8_t radius; //Radious needed from orbiting target 
    
    //Finding the radious from your GPS struct 
    uint8_t ori_rad = mydata->gps[mydata->my_coord].d_origin;
    uint8_t sda_rad = mydata->gps[mydata->my_coord].d_seeda;
    uint8_t sdb_rad = mydata->gps[mydata->my_coord].d_seedb;
    
    //Picking the largest radious of the three 
    //And setting your target to be that ID
    if(ori_rad >= sda_rad && ori_rad >= sdb_rad) {
        target = mydata->gps[ORIGIN].desig_id;
        radius = ori_rad;
    }
    else if(sda_rad >= ori_rad && sda_rad >= sdb_rad) {
        target = mydata->gps[SEEDA].desig_id;
        radius = sda_rad;
    }
    else {
        target = mydata->gps[SEEDB].desig_id;
        radius = sdb_rad;
    }
    //Seeing if your orbit target is in your neighbor list 
    if(exists_nearest_neighbor(target) < mydata->num_neighbors) {
        k++;
    }
    //debug code 
    
    /*if(kilo_uid == 10) {
        printf("now: %d\n", mydata->now);
        for(i = 0; i < mydata->num_neighbors; i++) {
            printf("neighbor: %d\n", mydata->nearest_neighbors[i].id);
        }
        printf("\n");
        
    }*/
    
    //Prev_climb is probably not used, However dont delete 
    //This loop finding the distance to the next lower gradiant to move towards it
    for(i = 0; i < mydata->num_neighbors; i++) {
        if(mydata->nearest_neighbors[i].grad < mydata->gradient) {
            mydata->climb_dist = mydata->nearest_neighbors[i].distance;
            mydata->prev_climb = mydata->climb_target;
            mydata->climb_target = mydata->nearest_neighbors[i].id;
            break;
        }
    }
    // J is the distance to your closest neighbor
    //This loop is running through all neighbors to set J 
    for(i = 0; i < mydata->num_neighbors; i++) {
        if(j > mydata->nearest_neighbors[i].distance) {
            j = mydata->nearest_neighbors[i].distance;
            mydata->orbit_target = mydata->nearest_neighbors[i].id;
        }
    }
    // if k== 0 then your orbit target is not in your neighbors list 
    if(k == 0) {
        //if yoru clim distance is grate then climb 
        //else avoid 
        if(j > 60) gradient_climb(mydata->climb_dist);
        else avoidance_orbit(j);
    }
    // Else your orbit target is in your neighbor list 
    else if (k != 0) {
        //Start orbiting 
        seed_orbit(target, radius);
        //Index in your neighbor list of those neighbors 
        uint8_t ori_ind = exists_nearest_neighbor(mydata->gps[ORIGIN].desig_id);
        uint8_t sda_ind = exists_nearest_neighbor(mydata->gps[SEEDA].desig_id);
        uint8_t sdb_ind = exists_nearest_neighbor(mydata->gps[SEEDB].desig_id);
        //These are the distances of origin, seeda, seedb
        uint8_t ori_dist = mydata->nearest_neighbors[ori_ind].distance;
        uint8_t sda_dist = mydata->nearest_neighbors[sda_ind].distance;
        uint8_t sdb_dist = mydata->nearest_neighbors[sdb_ind].distance;
        ///Calulcation of how far you are from your designated coordinates 
        uint16_t approx_error = (ori_dist-ori_rad)*(ori_dist-ori_rad)
                + (sda_dist-sda_rad)*(sda_dist-sda_rad)
                + (sdb_dist-sdb_rad)*(sdb_dist-sdb_rad);
        // Threshhold for deciding if you are placed or not 
        //These are all flags 
        if(approx_error <= 15) {
            mydata->placed = TRUE;
            mydata->updating = TRUE;
            mydata->moving = FALSE;
            mydata->safe = FALSE;
            set_motion(STOP);
            mydata->state = STOP;
        }
    }
    else {}
    
}
//After nodes are placed this function will be called 
//To update there gps strucst 
//These are payloads 
void send_update() {
    mydata->message[mydata->tail].data[TYPE] = UPDATE;
    mydata->message[mydata->tail].data[TARGET_ID] = 255;
    mydata->message[mydata->tail].data[RESPONSE_ID] = mydata->my_id;
    mydata->message[mydata->tail].data[RESPONSE_VAL] = 0;
    mydata->message[mydata->tail].data[COORDINATES] = mydata->my_coord;
    mydata->message[mydata->tail].data[SAFE] = FALSE;
}

void loop()
{
    delay(30);
    //Delay to populate neighbors data 
    if(mydata->now == 50) {
        seed_start();
    }
    //While still determining seed, using seed_update
    if(mydata->forming == FALSE) {
        seeding_update();
    }
    //When your seeding, then you can set our forming flag as true
    //The delay is needed to allow time for msgs and every bot can
    //Update safely 
    if(mydata->seeded == TRUE && mydata->now > mydata->seed_time + 50) {
        mydata->forming = TRUE;
    }
    //If you are not searching, and you are not commanding a 
    //move(no one in system moving), and its been last_placed_time + 200, start a new search
    if(mydata->entity == OVERLORD
            && mydata->now > mydata->last_placed_time + 200
            && mydata->searching == FALSE
            && mydata->moving == FALSE) {
        //printf("search\n");
        search_brdcst();
    }
    //Non-overlord nodes: if search is being issued then search_cnvgcst
    //their replying to the search_brdcst().
    if(mydata->searching == TRUE && mydata->now > mydata->last_update_time + 150) {
        search_cnvgcst();
    }
    //Redunant check. Do not remove. Overlord is true when cnvgcst is over 
    //and overlord has an id to work with. Send move to that id w/ coordinates
    if(mydata->entity == OVERLORD && mydata->safe == TRUE
            && mydata->gps[mydata->progress].desig_id == 0) {
        send_move(mydata->progress);
    }
    //Node has recieved movement from overlord, now it calles movement (duh)
    if(mydata->moving == TRUE && mydata->entity != OVERLORD
            && mydata->placed == FALSE) {
        //printf("%d: move\n",mydata->now);
        movement();
    }
    
   //Responding is marked true when convergcast responds that all 
   //Your children are safe so now you are safe 
    if(mydata->responding == TRUE) {
        search_response();
    }
    //Updating is marked true after a node has been placed 
    if(mydata->updating == TRUE) {
        send_update();
    }
    //DOesnt do much, however DO NOT REMOVE.
    mydata->loneliness++;
    //Clears your neighbor data
    if (mydata->loneliness > 100)
    {
        reset_self();
    }
    //This will clean the forwarding msgs 
    if(mydata->now > mydata->clean_time + 200) {
        mydata->cleaning = FALSE;
    }
    mydata->now++;
    
    //Only place that it sends messages 
    //The rest is just updates the mssging queue
    send_sharing();

    uint8_t i;
    //This is from ring
    //If you are not recvieveing a message form you neighbor 
    //Then remove him from you struct. 
    
    for (i = 0; i < mydata->num_neighbors; i++)
    {
        mydata->nearest_neighbors[i].message_recv_delay++;

        if (mydata->nearest_neighbors[i].message_recv_delay > 100)
        {    //Come back and clean data here!!!
            //Add clearing of data to function below 
            remove_neighbor(mydata->nearest_neighbors[i]);
            break;
        }
    }
    //Just changing color 
    update_color();
}


message_t *message_tx()
{
    
    if (mydata->tail != mydata->head)   // Queue is not empty
    {
        return &mydata->message[mydata->head];
    }
    return &mydata->nullmessage;
}
 
void message_tx_success() {
    if (mydata->tail != mydata->head) {  // Queue is not empty
        if (mydata->copies == 2)
        {
            mydata->head++;
            mydata->copies = 0;
            mydata->head = mydata->head % QUEUE;
        }
        else
        {
            mydata->copies++;
        }
    }
}

//Seed Determination 
//Justin said change the name here 
//We only going to call it once
//3 nodes are set in a triangle 
//12 nodes random placement within broadcast range 
//If you have 2 neighbors with distance less than 40 
// then you will create the seed 
//This can change later on
void seed_start() {
    
    uint8_t i; 
    uint8_t j = 0;
    //Iterating to find adjacent neighbors
    for(i = 0; i < mydata->num_neighbors; i++) {
        if(mydata->nearest_neighbors[i].distance < 40) {
            j++; 
        }
    }

    //If two neighbors are found,then you are a seed canidate
    if(j == 2) {
        mydata->entity = WARLORD;
        mydata->war = TRUE;
        mydata->gradient = 0;
    }
}

//This function is the bot initializing 
//This will initialized all variables associated with the bots
void setup() {
    
    rand_seed(rand_hard());

    mydata->my_id = rand_soft();
    
    //If you id is 255 then switch it to 254
    //We are using 255 as a broadcast ID
    if(mydata->my_id == 255) {
        mydata->my_id--;
    }
    
    //This is setting the state and id
    mydata->entity = SOVEREIGN;
    mydata->ruler_id = mydata->my_id;
    mydata->gradient = 255;
    mydata->seed_time = 0;
    mydata->last_placed_time = 0;
    mydata->resp_val = 0;
    mydata->resp_id = 0;
    mydata->progress = 3;
    mydata->my_coord = 0;
    mydata->last_update_time = 0;
    //Cleaning is used to allow forwarded msgs to die out
    mydata->cleaning = FALSE;
    mydata->clean_time = 0;
        
    //seed determination flags
    mydata->war = FALSE;
    mydata->seeded = FALSE;
    
    //node placement flags
    mydata->forming = FALSE;
    mydata->placed = FALSE;
    mydata->searching = FALSE;
    mydata->moving = FALSE;
    mydata->safe = FALSE;
    mydata->responding = FALSE;
    mydata->updating = FALSE;

    mydata->num_neighbors = 0;
    mydata->message_sent = 0,
    mydata->now = 0,
    mydata->nextShareSending = SHARING_TIME,
    mydata->cur_motion = STOP;
    mydata->motion_state = STOP;
    mydata->time_active = 0;
    mydata->move_state = 0;
    mydata->move_motion[0].motion = LEFT;
    mydata->move_motion[0].motion = 3;
    mydata->move_motion[1].motion = RIGHT;
    mydata->move_motion[1].motion = 5;
    mydata->move_motion[0].motion = LEFT;
    mydata->move_motion[0].motion = 2;
    mydata->red = 0,
    mydata->green = 0,
    mydata->blue = 0,
    mydata->send_token = 0;
    
    mydata->msg_log[0] = 255;
    mydata->msg_log[1] = 255;
    
    uint8_t i;
    //Initializing all your neighbor data
    for(i = 0; i < MAX_NUM_NEIGHBORS; i++) {
        mydata->nearest_neighbors[i].id = 0;
        mydata->nearest_neighbors[i].distance = 255;
        mydata->nearest_neighbors[i].grad = 255;
        mydata->nearest_neighbors[i].type = 255;
        mydata->nearest_neighbors[i].ruler = 0;
        mydata->nearest_neighbors[i].resp_val = 0;
        mydata->nearest_neighbors[i].safe = FALSE;
        mydata->nearest_neighbors[i].resp_id = 0;

        mydata->nearest_neighbors[i].message_recv_delay = 0;
    }
    //Initializing your GPS struct located in ferris.h
    for(i = 0; i < MAX_NUM_NEIGHBORS; i++) {
        mydata->gps[i].desig_id = 0;
        mydata->gps[i].d_origin = 255;
        mydata->gps[i].d_seeda = 255;
        mydata->gps[i].d_seedb = 255;
        mydata->gps[i].d_N = 255;
        mydata->gps[i].d_NE = 255;
        mydata->gps[i].d_SE = 255;
        mydata->gps[i].d_S = 255;
        mydata->gps[i].d_SW = 255;
        mydata->gps[i].d_NW = 255;
        mydata->gps[i].d_FNE = 255;
        mydata->gps[i].d_FE = 255;
        mydata->gps[i].d_FSE = 255;
        mydata->gps[i].d_FSW = 255;
        mydata->gps[i].d_FW = 255;
        mydata->gps[i].d_FNW = 255;
        mydata->gps[i].placed = FALSE;
    }
    //Setting the real distances associated with the coordinates 

    //Seed
    mydata->gps[ORIGIN].d_origin = 0;
    mydata->gps[ORIGIN].d_seeda = 30;
    mydata->gps[ORIGIN].d_seedb = 30;
    //Seed
    mydata->gps[SEEDA].d_origin = 30;
    mydata->gps[SEEDA].d_seeda = 0;
    mydata->gps[SEEDA].d_seedb = 30;
    //Seed
    mydata->gps[SEEDB].d_origin = 30;
    mydata->gps[SEEDB].d_seeda = 30;
    mydata->gps[SEEDB].d_seedb = 0;
    //Inner Six starts here 
    mydata->gps[N].d_origin = 63;
    mydata->gps[N].d_seeda = 90;
    mydata->gps[N].d_seedb = 90;
    
    mydata->gps[NE].d_origin = 66;
    mydata->gps[NE].d_seeda = 90;
    mydata->gps[NE].d_seedb = 66;
    
    mydata->gps[SSE].d_origin = 90;
    mydata->gps[SSE].d_seeda = 90;
    mydata->gps[SSE].d_seedb = 63;
    
    mydata->gps[S].d_origin = 90;
    mydata->gps[S].d_seeda = 66;
    mydata->gps[S].d_seedb = 66;
    
    mydata->gps[SW].d_origin = 90;
    mydata->gps[SW].d_seeda = 63;
    mydata->gps[SW].d_seedb = 90;
    
    mydata->gps[NW].d_origin = 66;
    mydata->gps[NW].d_seeda = 66;
    mydata->gps[NW].d_seedb = 90;
    // End of inner six 
    
    //Out six 
    mydata->gps[FNE].d_N = 90;
    mydata->gps[FNE].d_NE = 90;
    mydata->gps[FE].d_NE = 90;
    mydata->gps[FE].d_SE = 90;
    mydata->gps[FSE].d_SE = 90;
    mydata->gps[FSE].d_S = 90;
    mydata->gps[FSW].d_S = 90;
    mydata->gps[FSW].d_SW = 90;
    mydata->gps[FW].d_SW = 90;
    mydata->gps[FW].d_NW = 90;
    mydata->gps[FNW].d_NW = 90;
    mydata->gps[FNW].d_N = 90;
    //End of outer six
    
    mydata->nullmessage.data[MSG] = NULL_MSG;
    mydata->nullmessage.crc = message_crc(&mydata->nullmessage);
    
    mydata->token = rand_soft() < 128  ? 1 : 0;
    //mydata->blue = mydata->token;
    mydata->head = 0;
    mydata->tail = 0;
    mydata->copies = 0;
    

   
#ifdef SIMULATOR
    printf("Initializing %d %d\n", kilo_uid, mydata->my_id);
#endif

    mydata->message_sent = 1;
}

int main() {
    kilo_init();
    kilo_message_tx = message_tx;
    kilo_message_tx_success = message_tx_success;
    kilo_message_rx = message_rx;
    kilo_start(setup, loop);
    
    
    return 0;
}


